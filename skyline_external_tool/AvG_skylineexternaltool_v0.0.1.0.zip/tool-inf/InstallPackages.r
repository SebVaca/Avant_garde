install.packages("GA" , repos='http://cran.us.r-project.org')
install.packages("doSNOW" , repos='http://cran.us.r-project.org')
install.packages("snow" , repos='http://cran.us.r-project.org')
install.packages("iterators" , repos='http://cran.us.r-project.org')
install.packages("foreach" , repos='http://cran.us.r-project.org')
install.packages("digest" , repos='http://cran.us.r-project.org')
install.packages("sqldf" , repos='http://cran.us.r-project.org')
install.packages("RSQLite" , repos='http://cran.us.r-project.org')
install.packages("gsubfn" , repos='http://cran.us.r-project.org')
install.packages("proto" , repos='http://cran.us.r-project.org')
install.packages("data.table" , repos='http://cran.us.r-project.org')
install.packages("stringr" , repos='http://cran.us.r-project.org')
install.packages("tidyr" , repos='http://cran.us.r-project.org')
install.packages("dplyr" , repos='http://cran.us.r-project.org')


# ## Install AvantGarde Package if it is not already installed
# a<-installed.packages()
# packages<-a[,1]
# if (!is.element("AvantGardeDIA",packages) || packageVersion("AvantGardeDIA") < "0.0.0.0" ){
#   install.packages(Avg_RPackage_path,repos = NULL)
# }
